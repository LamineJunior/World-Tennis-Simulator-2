document.addEventListener("DOMContentLoaded", () => {
    const container = document.getElementById("career-container");
    container.innerHTML = "<p>Career simulation is under development. Player progress, seasons, and rankings will appear here.</p>";
});