
from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/editor')
def editor():
    return render_template('editor.html')

@app.route('/match')
def match():
    return render_template('match.html')

@app.route('/tournament')
def tournament():
    return render_template('tournament.html')

@app.route('/career')
def career():
    return render_template('career.html')

if __name__ == '__main__':
    app.run(debug=True)
