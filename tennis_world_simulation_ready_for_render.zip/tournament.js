
document.getElementById('tournamentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const numPlayers = parseInt(document.getElementById('numPlayers').value);
    const surface = document.getElementById('surface').value;
    let results = `<h2>Tournoi sur ${surface} avec ${numPlayers} joueurs</h2><ul>`;
    for (let round = 1; numPlayers / Math.pow(2, round - 1) >= 1; round++) {
        const roundSize = numPlayers / Math.pow(2, round - 1);
        if (roundSize >= 1) {
            results += `<li>Tour ${round}: ${roundSize} joueurs</li>`;
        }
    }
    results += "</ul>";
    document.getElementById('results').innerHTML = results;
});
